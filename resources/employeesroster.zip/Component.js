sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("employeesroster.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map